/**
 * Created by zhangxuancheng on 2018/12/23.
 */
var roseChart = echarts.init(document.getElementById('roseMap'));
var data_0 = [];
var data_1 = [];
var data_2 = [];
var data_3 = [];
var data_4 = [];
var data_5 = [];
var degree  = 0;
var hashMapTotalNumber = {}; //使用一个字典存储类别和列别的总数
var timerRose;
InitRoseMap();
function makeData(){
    data_0 = [];data_1 = [];data_2 = [];data_3 = [];data_4 = [];data_5 = [];
    for(n = 0; n < 12*24; n++) data_0[n] = 80;
    for(n = 0; n < 12*24; n++) data_1[n] = 0;
    for(n = 0; n < 12*24; n++) data_2[n] = 0;
    for(n = 0; n < 12*24; n++) data_3[n] = 0;
    for(n = 0; n < 12*24; n++) data_4[n] = 0;
    for(n = 0; n < 12*24; n++) data_5[n] = 0;
    var max = 0;
    data_Tag1_user = selectDataByUserRoseMap(data_Tag1,userToShow);
    data_Tag2_user = selectDataByUserRoseMap(data_Tag2,userToShow);
    data_Tag3_user = selectDataByUserRoseMap(data_Tag3,userToShow);
    data_Tag4_user = selectDataByUserRoseMap(data_Tag4,userToShow);
    data_Tag5_user = selectDataByUserRoseMap(data_Tag5,userToShow);

    for(i=0;i<data_Tag1_user.length;i++){
        index = Math.floor((data_Tag1_user[i].recitime-time)/timepass)
        data_1[index] = data_1[index]+1;
        if(data_1[index]>max) max = data_1[index];
    }
    for(i=0;i<data_Tag2_user.length;i++){
        index = Math.floor((data_Tag2_user[i].recitime-time)/timepass)
        data_2[index] = data_2[index]+1;
        if(data_2[index]>max) max = data_2[index];
    }
    for(i=0;i<data_Tag3_user.length;i++){
        index = Math.floor((data_Tag3_user[i].recitime-time)/timepass)
        data_3[index] = data_3[index]+1;
        if(data_3[index]>max) max = data_3[index];

    }
    for(i=0;i<data_Tag4_user.length;i++){
        index = Math.floor((data_Tag4_user[i].recitime-time)/timepass)
        data_4[index] = data_4[index]+1;
        if(data_4[index]>max) max = data_4[index];

    }
    for(i=0;i<data_Tag5_user.length;i++){
        index = Math.floor((data_Tag5_user[i].recitime-time)/timepass)
        data_5[index] = data_5[index]+1;
        if(data_5[index]>max) max = data_5[index];

    }
    for(var n = 0; n < 12*24; n++) data_0[n] = max/10;
    hashMapTotalNumber['出租车'] = eval(data_1.join("+"));
    hashMapTotalNumber['公交车'] = eval(data_2.join("+"));
    hashMapTotalNumber['私家车'] = eval(data_3.join("+"));
    hashMapTotalNumber['地铁'] = eval(data_4.join("+"));
    hashMapTotalNumber['自行车'] = eval(data_5.join("+"));

}
function InitRoseMap() {
    optionRoseChart = {
        angleAxis: {
            show: false,
            type: 'category',
            data: makeData(),
            z: 10,
        },
        radiusAxis: {
            axisLine: {
                lineStyle: {
                type: 'solid',
                color:'#fff',
                width:'1'
                }
            }
        },
        tooltip:{
            formatter: function (params) {
                return params.seriesName
                    +'<br>时间:<t>'+Math.floor(params.name*timepass/1000/3600)+':'+Math.floor(params.name*timepass/1000%3600/300*5)
                    +'<br>数量:<t>'+params.value
                    + '<br>占比:<t>'+((params.value / (data_1[params.name]+data_2[params.name]+data_3[params.name]+data_4[params.name]+data_5[params.name]))*100).toFixed(2)+'%'
            }
        },
        polar: {},
        series: [{
            type: 'bar',
            data: data_0,
            coordinateSystem: 'polar',
            name: '',
            stack: 'a',
            color: 'transparent'
        }, {
            type: 'bar',
            data: data_1,
            coordinateSystem: 'polar',
            name: '出租车',
            stack: 'a',
            // color: 'purple'
            color: '#ce504a'

        }, {
            type: 'bar',
            data: data_2,
            coordinateSystem: 'polar',
            name: '公交车',
            stack: 'a',
            // color: 'blue'
            color: '#f7c550'

        }, {
            type: 'bar',
            data: data_3,
            coordinateSystem: 'polar',
            name: '私家车',
            stack: 'a',
            // color: 'green'
            color:'#9aeec1'
        }, {
            type: 'bar',
            data: data_4,
            coordinateSystem: 'polar',
            name: '地铁',
            stack: 'a',
            color: '#52a1d5'
        }, {
            type: 'bar',
            data: data_5,
            coordinateSystem: 'polar',
            name: '自行车',
            stack: 'a',
            // color: 'pink',
            color:'#7f7ec3'
        },
            {
                name: '',
                type: 'gauge',
                min: 0,
                max: 24,
                startAngle: 90,
                endAngle: 449.9,
                radius: '82%',
                splitNumber: 24,
                clockwise: false,
                animation: false,
                detail: {
                    formatter: '{value}',
                    textStyle: {
                        color: '#63869e'
                    }
                },
                detail: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                axisLine: {
                    lineStyle: {
                        color: [
                            [0.25, '#63869e'],
                            [0.75, '#ffffff'],
                            [1, '#63869e']
                        ],
                        width: '5',
                        shadowColor: '#0d4b81', //默认透明
                        shadowBlur: 40,
                        opacity: 1
                    }
                },
                splitLine: {
                    length: 5,
                    lineStyle: {
                        color: '#ffffff',
                        width: 2
                    }
                },
                axisLabel: {
                    formatter: function (v) {
                        return v ? v : '';
                    },
                    textStyle: {
                        color: "red",
                        fontWeight: 700
                    }
                },
                itemStyle: {
                    normal: {
                        color: 'red',
                        width: 2
                    }
                },
                pointer: { //仪表盘指针
                    show: true,
                    length: '100%',
                    width: 1
                },
                data: [{}],
                zlevel: 1
            }],
        legend: {
            show: true,
            data: ['出租车', '公交车', '私家车','地铁','自行车'],
            bottom: 0,
            textStyle: {
                color: '#fff'          // 图例文字颜色
            },
            tooltip:{
                show:true,
                formatter: function(params){
                    return '总数:'+hashMapTotalNumber[params.name] +'<br>' +
                        '占比:'+ (hashMapTotalNumber[params.name] /
                        (hashMapTotalNumber['出租车']
                        +hashMapTotalNumber['公交车']
                        +hashMapTotalNumber['私家车']
                        +hashMapTotalNumber['地铁']
                        +hashMapTotalNumber['自行车'])*100).toFixed(2) +'%'
                }
            }
        }
    };
    roseChart.setOption(optionRoseChart);
    roseChart.off('legendselectchanged');
    roseChart.on('legendselectchanged', function (params) {
        if(params.name=='出租车' && data_Flag1 == 1) {
            data_Flag1 = 0;
        }
        else if(params.name=='出租车' && data_Flag1==0){
            data_Flag1 = 1;
        }
        if(params.name=='公交车' && data_Flag2 == 1) {
            data_Flag2 = 0;
        }
        else if(params.name=='公交车' && data_Flag2==0){
            data_Flag2 = 1;
        }
        if(params.name=='私家车' && data_Flag3 == 1) {
            data_Flag3 = 0;
        }
        else if(params.name=='私家车' && data_Flag3==0){
            data_Flag3 = 1;
        }
        if(params.name=='地铁' && data_Flag4 == 1) {
            data_Flag4 = 0;
        }
        else if(params.name=='地铁' && data_Flag4==0){
            data_Flag4 = 1;
        }
        if(params.name=='自行车' && data_Flag5 == 1) {
            data_Flag5 = 0;
        }
        else if(params.name=='自行车' && data_Flag5==0){
            data_Flag5 = 1;
        }
        if(!timer){
            var myChart = echarts.init(document.getElementById('main'));
            myChart.setOption(option);
        }
    });

}
function playRoseMap() {
    // degree = (time+start_time) / (5*60*1000) * 0.00833333 * 10;
    if(start_time!=0 ){
        degree = (start_time) / (5*60*1000) * 0.00833333 * 10;
        start_time = 0;
    }
    timerRose = setInterval(function() {
        optionRoseChart.series[6].data[0].value = (degree);
        degree = degree +0.00833333 * 10;
         // optionRoseChart.series[6].data[0].value = (seconds).toFixed(2);
        roseChart.setOption(optionRoseChart);
    }, 1000/speed);
}
function stopRoseMap() {
    // degree=0;
    degree = start_time / (5*60*1000) * 0.00833333 * 10;
    optionRoseChart.series[6].data[0].value = (degree);
    roseChart.setOption(optionRoseChart,true);
}
