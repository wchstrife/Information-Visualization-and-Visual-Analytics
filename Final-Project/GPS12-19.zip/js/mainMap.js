/**
 * Created by zhangxuancheng on 2018/12/23.
 */
var colorMap = ["#2F0000","#600030","#460046","#28004D","#4D0000","#820041","#5E005E","#3A006F","#600000","#9F0050","#750075","#4B0091","#750000","#BF0060","#930093","#5B00AE","#930000","#D9006C","#AE00AE","#6F00D2","#AE0000","#F00078","#D200D2","#8600FF","#CE0000","#FF0080","#E800E8","#921AFF","#EA0000","#FF359A","#FF00FF","#9F35FF","#FF0000","#FF60AF","#FF44FF","#B15BFF","#FF2D2D","#FF79BC","#FF77FF","#BE77FF","#FF5151","#FF95CA","#FF8EFF","#CA8EFF","#FF7575","#FFAAD5","#FFA6FF","#D3A4FF","#FF9797","#FFC1E0","#FFBFFF","#DCB5FF","#FFB5B5","#FFD9EC","#FFD0FF","#E6CAFF","#FFD2D2","#FFECF5","#FFE6FF","#F1E1FF","#FFECEC","#FFF7FB","#FFF7FF","#FAF4FF","#000079","#000079","#003E3E","#006030","#006000","#000093","#003D79","#005757","#01814A","#007500","#0000C6","#004B97","#007979","#019858","#009100","#0000C6","#005AB5","#009393","#01B468","#00A600","#0000E3","#0066CC","#00AEAE","#02C874","#00BB00","#2828FF","#0072E3","#00CACA","#02DF82","#00DB00","#4A4AFF","#0080FF","#00E3E3","#02F78E","#00EC00","#6A6AFF","#2894FF","#00FFFF","#1AFD9C","#28FF28","#7D7DFF","#46A3FF","#4DFFFF","#4EFEB3","#53FF53","#9393FF","#66B3FF","#80FFFF","#7AFEC6","#79FF79","#AAAAFF","#84C1FF","#A6FFFF","#96FED1","#93FF93","#B9B9FF","#97CBFF","#BBFFFF","#ADFEDC","#A6FFA6","#CECEFF","#ACD6FF","#CAFFFF","#C1FFE4","#BBFFBB","#DDDDFF","#C4E1FF","#D9FFFF","#D7FFEE","#CEFFCE","#ECECFF","#D2E9FF","#ECFFFF","#E8FFF5","#DFFFDF","#FBFBFF","#ECF5FF","#FDFFFF","#FBFFFD","#F0FFF0","#467500","#424200","#5B4B00","#844200","#642100","#548C00","#5B5B00","#796400","#9F5000","#842B00","#64A600","#737300","#977C00","#BB5E00","#A23400","#73BF00","#8C8C00","#AE8F00","#D26900","#BB3D00","#82D900","#A6A600","#C6A300","#EA7500","#D94600","#8CEA00","#C4C400","#D9B300","#FF8000","#F75000","#9AFF02","#E1E100","#EAC100","#FF9224","#FF5809","#A8FF24","#F9F900","#FFD306","#FFA042","#FF8040","#B7FF4A","#FFFF37","#FFDC35","#FFAF60","#FF8F59","#C2FF68","#FFFF6F","#FFE153","#FFBB77","#FF9D6F","#CCFF80","#FFFF93","#FFE66F","#FFC78E","#FFAD86","#D3FF93","#FFFFAA","#FFED97","#FFD1A4","#FFBD9D","#DEFFAC","#FFFFB9","#FFF0AC","#FFDCB9","#FFCBB3","#E8FFC4","#FFFFCE","#FFF4C1","#FFE4CA","#FFDAC8","#EFFFD7","#FFFFDF","#FFF8D7","#FFEEDD","#FFE6D9","#F5FFE8","#FFFFF4","#FFFCEC","#FFFAF4","#FFF3EE","#613030","#616130","#336666","#484891","#6C3365","#743A3A","#707038","#3D7878","#5151A2","#7E3D76","#804040","#808040","#408080","#5A5AAD","#8F4586","#984B4B","#949449","#4F9D9D","#7373B9","#9F4D95","#AD5A5A","#A5A552","#5CADAD","#8080C0","#AE57A4","#B87070","#AFAF61","#6FB7B7","#9999CC","#B766AD","#C48888","#B9B973","#81C0C0","#A6A6D2","#C07AB8","#CF9E9E","#C2C287","#95CACA","#B8B8DC","#CA8EC2","#D9B3B3","#CDCD9A","#A3D1D1","#C7C7E2","#D2A2CC","#E1C4C4","#D6D6AD","#B3D9D9","#D8D8EB","#DAB1D5","#EBD6D6","#DEDEBE","#C4E1E1","#E6E6F2","#E2C2DE","#F2E6E6","#E8E8D0","#D1E9E9","#F3F3FA","#EBD3E8"];
//定义地理位置信息
var geoCoordMap_Tag1 = {};
var geoCoordMap_Tag2 = {};
var geoCoordMap_Tag3 = {};
var geoCoordMap_Tag4 = {};
var geoCoordMap_Tag5 = {};
//定义数据变量
var data_Tag1 = [];
var data_Tag2 = [];
var data_Tag3 = [];
var data_Tag4 = [];
var data_Tag5 = [];
//标记是否画点
var data_Flag1 = 1;
var data_Flag2 = 1;
var data_Flag3 = 1;
var data_Flag4 = 1;
var data_Flag5 = 1;
//定义每个点的大小
var SizeDict_Tag1;
var SizeDict_Tag2;
var SizeDict_Tag3;
var SizeDict_Tag4;
var SizeDict_Tag5;
//真实画点的数据
var dataScatter_Tag1;
var dataScatter_Tag2;
var dataScatter_Tag3;
var dataScatter_Tag4;
var dataScatter_Tag5;
var userToShow = []; //画在地图上的轨迹编号
var dictAllDataAllTag ={};
var tag2name = {
    1:'出租车',
    2:'公交车',
    3:'私家车',
    4:'地铁',
    5:'自行车'
};
option = {
    title: {
        text: 'GPS轨迹多维度可视分析软件',
        left: 'center',
        textStyle:{
            color:'white'
        }
    },
    tooltip: {
        trigger: 'item'
    },
    bmap: {
        center: [116.42990875, 39.91577911],
        zoom: 12,
        roam: false,
        mapStyle: {
            //描绘地图样式
            styleJson: [{
                'featureType': 'water',
                'elementType': 'all',
                'stylers': {
                    'color': '#031628'
                }
            },
                {
                    'featureType': 'land',
                    'elementType': 'geometry',
                    'stylers': {
                        'color': '#000102'
                    }
                },
                {
                    'featureType': 'highway',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                },
                {
                    'featureType': 'arterial',
                    'elementType': 'geometry.fill',
                    'stylers': {
                        'color': '#000000'
                    }
                },
                {
                    'featureType': 'arterial',
                    'elementType': 'geometry.stroke',
                    'stylers': {
                        'color': '#0b3d51'
                    }
                },
                {
                    'featureType': 'local',
                    'elementType': 'geometry',
                    'stylers': {
                        'color': '#000000'
                    }
                },
                {
                    'featureType': 'railway',
                    'elementType': 'geometry.fill',
                    'stylers': {
                        'color': '#000000'
                    }
                },
                {
                    'featureType': 'railway',
                    'elementType': 'geometry.stroke',
                    'stylers': {
                        'color': '#08304b'
                    }
                },
                {
                    'featureType': 'subway',
                    'elementType': 'geometry',
                    'stylers': {
                        'lightness': -70
                    }
                },
                {
                    'featureType': 'building',
                    'elementType': 'geometry.fill',
                    'stylers': {
                        'color': '#000000'
                    }
                },
                {
                    'featureType': 'all',
                    'elementType': 'labels.text.fill',
                    'stylers': {
                        'color': '#857f7f'
                    }
                },
                {
                    'featureType': 'all',
                    'elementType': 'labels.text.stroke',
                    'stylers': {
                        'color': '#000000'
                    }
                },
                {
                    'featureType': 'building',
                    'elementType': 'geometry',
                    'stylers': {
                        'color': '#022338'
                    }
                },
                {
                    'featureType': 'green',
                    'elementType': 'geometry',
                    'stylers': {
                        'color': '#062032'
                    }
                },
                {
                    'featureType': 'boundary',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#465b6c'
                    }
                },
                {
                    'featureType': 'manmade',
                    'elementType': 'all',
                    'stylers': {
                        'color': '#022338'
                    }
                },
                {
                    'featureType': 'label',
                    'elementType': 'all',
                    'stylers': {
                        'visibility': 'off'
                    }
                }]
        }
    },
    series: []
};
var myDate = new Date();
var time;
var timer;
var start_time;
var end_time;
var timepass = 5 * 60 * 1000;
var speed;
var frame=0;
var zoomRate = 12;
var SymbleSizeFlag = 1;
var ColorFlag = 0;
var SymbleSize = 3;
var timerClick = null;
// makeList();
showMap();
showMap();
setTimeout(showMap,1500);
function sleep(delay) {
    var start = (new Date()).getTime();
    while ((new Date()).getTime() - start < delay) {
        continue;
    }
}
function showMap() {
    var myChart = echarts.init(document.getElementById('main'));
    myChart.setOption(option);
}
function loadData() {
    file = $('#calendarSelect').val().replace(/-/g,'');
    var myChart = echarts.init(document.getElementById('main'));
    myChart.showLoading();
    option.series = []
    var filename = 'NewJson/' + file + 'New.json';
    var year = file.slice(0, 4);
    var month = file.slice(4, 6);
    var day = file.slice(6, 8);
    myDate.setFullYear(year, month - 1, day);

    myDate.setHours(0);
    myDate.setMinutes(0);
    myDate.setSeconds(0);
    myDate.setMilliseconds(0);
    time = myDate.getTime();
    $.get(filename,
        function (result) {
            for (var i = 0; i < result.length; i++) {
                tmp = {};
                tmp['name'] = result[i]['id'];
                tmp['value'] = 100;
                tmp['recitime'] = result[i]['recitime'];
                tmp['content'] = result[i]['content'];
                tmp['user'] = result[i]['user']

                //安装经纬度存储下所有的信息
                if (!dictAllDataAllTag.hasOwnProperty([result[i]['lng'], result[i]['lat']])){
                    dictAllDataAllTag[[result[i]['lng'], result[i]['lat']]] = []
                }
                dictAllDataAllTag[[result[i]['lng'], result[i]['lat']]].push({
                    name:result[i]['id'],
                    recitime:result[i]['recitime'],
                    content:result[i]['content'],
                    tag:result[i]['tag'],
                    user:result[i]['user']
                });

                var tmp_geoCoordMap = [result[i]['lng'], result[i]['lat']]
                if (result[i]['tag'] == 1) {
                    geoCoordMap_Tag1[result[i]['id']] = tmp_geoCoordMap;
                    data_Tag1.push(tmp)
                }
                else if (result[i]['tag'] == 2) {
                    geoCoordMap_Tag2[result[i]['id']] = tmp_geoCoordMap;
                    data_Tag2.push(tmp)
                }
                else if (result[i]['tag'] == 3) {
                    geoCoordMap_Tag3[result[i]['id']] = tmp_geoCoordMap;
                    data_Tag3.push(tmp)
                }
                else if (result[i]['tag'] == 4) {
                    geoCoordMap_Tag4[result[i]['id']] = tmp_geoCoordMap;
                    data_Tag4.push(tmp)
                }
                else if (result[i]['tag'] == 5) {
                    geoCoordMap_Tag5[result[i]['id']] = tmp_geoCoordMap;
                    data_Tag5.push(tmp)
                }
            }
            start_time = (($('#startTimeSelect').val().slice(0,2)*3600+$('#startTimeSelect').val().slice(3,5)*60)*1000);
            end_time = (($('#endTimeSelect').val().slice(0,2)*3600+$('#endTimeSelect').val().slice(3,5)*60)*1000);
            if($('#endTimeSelect').val()=='00:00')
                end_time = 24 * 60 * 60 *1000;
            myChart.hideLoading();
            makeScatterData();
            makeAllSymbolSize();
            showAllData();
            makeData();
            InitRoseMap();
        }
    );
}
function makeSymbolSize(n) {
    dict ={}
    if(n==1)
        data = dataScatter_Tag1;
    if(n==2)
        data = dataScatter_Tag2;
    if(n==3)
        data = dataScatter_Tag3;
    if(n==4)
        data = dataScatter_Tag4;
    if(n==5)
        data = dataScatter_Tag5;
    for(i in data)
    {
        if(dict.hasOwnProperty([data[i].value[0],data[i].value[1]])){
            index = Math.floor((data[i].value[3]-time)/timepass)
            dict[[data[i].value[0],data[i].value[1]]][index] = dict[[data[i].value[0],data[i].value[1]]][index]+1;
        }else {
            var tmpArray=[];
            for(n = 0; n < 12*24; n++) tmpArray[n] = 0;
            dict[[data[i].value[0], data[i].value[1]]] = tmpArray;
            index = Math.floor((data[i].value[3]-time)/timepass)
            dict[[data[i].value[0],data[i].value[1]]][index] = dict[[data[i].value[0],data[i].value[1]]][index]+1;
        }
    }
    return dict;
}
function makeAllSymbolSize() {
    SizeDict_Tag1 = makeSymbolSize(1);
    SizeDict_Tag2 = makeSymbolSize(2);
    SizeDict_Tag3 = makeSymbolSize(3);
    SizeDict_Tag4 = makeSymbolSize(4);
    SizeDict_Tag5 = makeSymbolSize(5);
}

function makeScatterData() {
    dataScatter_Tag1 = convertData(data_Tag1,1);
    dataScatter_Tag2 = convertData(data_Tag2,2);
    dataScatter_Tag3 = convertData(data_Tag3,3);
    dataScatter_Tag4 = convertData(data_Tag4,4);
    dataScatter_Tag5 = convertData(data_Tag5,5);

}
var convertDataWithTime = function (data, n, time_now) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
        var geoCoord;
        if (n == 1)
            geoCoord = geoCoordMap_Tag1[data[i].name];
        if (n == 2)
            geoCoord = geoCoordMap_Tag2[data[i].name];
        if (n == 3)
            geoCoord = geoCoordMap_Tag3[data[i].name];
        if (n == 4)
            geoCoord = geoCoordMap_Tag4[data[i].name];
        if (n == 5)
            geoCoord = geoCoordMap_Tag5[data[i].name];
        if (geoCoord && data[i].recitime >= time_now && data[i].recitime <= (time_now+timepass)) {
            res.push({
                name: data[i].name,
                value: geoCoord.concat(data[i].user).concat(data[i].recitime)
            });
        }
    }
    return res;
};
var convertData = function (data, n) {
    var res = [];
    for (var i = 0; i < data.length; i++) {
        var geoCoord;
        if (n == 1)
            geoCoord = geoCoordMap_Tag1[data[i].name];
        if (n == 2)
            geoCoord = geoCoordMap_Tag2[data[i].name];
        if (n == 3)
            geoCoord = geoCoordMap_Tag3[data[i].name];
        if (n == 4)
            geoCoord = geoCoordMap_Tag4[data[i].name];
        if (n == 5)
            geoCoord = geoCoordMap_Tag5[data[i].name];
        if (geoCoord && data[i].recitime >= (time+start_time) && data[i].recitime <= (time+end_time) ) {
            res.push({
                name: data[i].name,
                value: geoCoord.concat(data[i].user).concat(data[i].recitime)
            });
        }
    }
    return res;
};

function selectDataByUser(data, user) {
    var res = [];
    if (user.length==0)
        return data;
    for (var i=0; i<data.length;i++){
        if (user.indexOf(data[i].value[2])!=-1){
            res.push(data[i])
        }
    }
    return res
}

function selectDataByUserRoseMap(data, user) {
    var res = [];
    if (user.length==0)
        return data;
    for (var i=0; i<data.length;i++){
        if (user.indexOf(data[i].user)!=-1){
            res.push(data[i])
        }
    }
    return res
}
function showTraj() {
    var inputId = $("#inputId").val();
    if(inputId==""){
        userToShow=[]
    }
    else {
        inputId = inputId.split(',');
        userToShow = inputId.map(Number);
    }
    option.series = [];
    showAllData()
    makeData();
    InitRoseMap();
}
function showAllData() {
    var myChart = echarts.init(document.getElementById('main'));
    option.series.push(
        {
            name: '出租车',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            // data: convertData(data_Tag1, 1),
            data: selectDataByUser(dataScatter_Tag1,userToShow),
            symbolSize: function (val) {
                // return 10 * data_Flag1;
                return SymbleSize * data_Flag1;
                // return SymbleSizeFlag==0?10:Math.log(eval(SizeDict_Tag1[[val[0],val[1]]].join("+"))) *5* data_Flag1;
            },
            // label: {
            //     normal: {
            //         formatter: '{c}',
            //         position: 'right',
            //         show: false
            //     },
            //     emphasis: {
            //         show: false
            //     }
            // },
            itemStyle: {
                normal: {
                    // color: 'purple'
                    // color:'#ce504a'
                    // color:function (params){
                    //     return ColorFlag==0?'#ce504a':('#'+Math.floor((params.value[2])/dataScatter_Tag1.length*16777215).toString(16))
                    // }
                    color:function (params){
                        return ColorFlag==0?'#ce504a':colorMap[params.value[2]]
                    }
                }
            },
            tooltip :{
                formatter:function (params){
                    if(!timer) {
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '出租车编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                    else {
                        console.log(Math.floor((params.value[3] - myDate.getTime()) / timepass))
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '出租车编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                }
            },
            animation:false
        },
        {
            name: '公交车',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            // data: convertData(data_Tag2, 2),
            data:selectDataByUser(dataScatter_Tag2,userToShow),
            symbolSize: function (val) {
                // return 10 * data_Flag2;
                // return SymbleSizeFlag==0?10:Math.log(eval(SizeDict_Tag2[[val[0],val[1]]].join("+"))) *5* data_Flag2;
                return SymbleSize * data_Flag2 ;
            },
            itemStyle: {
                normal: {
                    // color: 'blue'
                    // color:'#f7c550'
                    color:function (params){
                        return ColorFlag==0?'#f7c550':colorMap[params.value[2]]
                    }
                }
            },
            tooltip :{
                formatter:function (params){
                    if(!timer) {
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '公交车编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                    else {
                        console.log(Math.floor((params.value[3] - myDate.getTime()) / timepass))
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '公交车编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                }
            },
            animation:false
        },
        {
            name: '私家车',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            // data: convertData(data_Tag3, 3),
            data:selectDataByUser(dataScatter_Tag3,userToShow),
            symbolSize: function (val) {
                // return 10 * data_Flag3;
                // return SymbleSizeFlag==0?10:Math.log(eval(SizeDict_Tag3[[val[0],val[1]]].join("+"))) *5* data_Flag3;
                return SymbleSize  * data_Flag3 ;

            },
            itemStyle: {
                normal: {
                    // color: 'green'
                    // color:'#9aeec1'
                    color:function (params){
                        return ColorFlag==0?'#9aeec1':colorMap[params.value[2]]
                    }
                }
            },
            tooltip :{
                formatter:function (params){
                    if(!timer) {
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '私家车编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                    else {
                        console.log(Math.floor((params.value[3] - myDate.getTime()) / timepass))
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '私家车编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                }
            },
            animation:false
        },
        {
            name: '自行车',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            // data: convertData(data_Tag5, 5),
            data:selectDataByUser(dataScatter_Tag5,userToShow),
            symbolSize: function (val) {
                // return SymbleSizeFlag==0?10:Math.log(eval(SizeDict_Tag5[[val[0],val[1]]].join("+"))) *5* data_Flag5;
                return SymbleSize * data_Flag5 ;

            },
            itemStyle: {
                normal: {
                    // color:'#7f7ec3'
                    // color: 'pink'
                    color:function (params){
                        return ColorFlag==0?'#7f7ec3':colorMap[params.value[2]]
                    }
                }
            },
            tooltip :{
                formatter:function (params){
                    if(!timer) {
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '自行车编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                    else {
                        console.log(Math.floor((params.value[3] - myDate.getTime()) / timepass))
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '自行车编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                }
            },
            animation:false
        },
        {
            name: '地铁',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            // data: convertData(data_Tag4, 4),
            data:selectDataByUser(dataScatter_Tag4,userToShow),
            symbolSize: function (val) {
                // return 10 * data_Flag4;
                // return SymbleSizeFlag==0?10:Math.log(eval(SizeDict_Tag4[[val[0],val[1]]].join("+"))) *5* data_Flag4;
                return SymbleSize * data_Flag4;

            },
            itemStyle: {
                normal: {
                    // color: 'red'
                    // color:'#52a1d5'
                    color:function (params){
                        return ColorFlag==0?'#52a1d5':colorMap[params.value[2]]
                    }
                }
            },
            tooltip :{
                formatter:function (params){
                    if(!timer) {
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '地铁编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                    else {
                        console.log(Math.floor((params.value[3] - myDate.getTime()) / timepass))
                        return '类别:' + params.seriesName + '<br>'
                            + '基站位置: ' + '经度:' + params.value[0] + '<t> 纬度:' + params.value[1] + '<br>'
                            + '地铁编号:' + params.value[2]+ '<br>'
                            + '时间:' + new Date(params.value[3]).getHours() + ':' + new Date(params.value[3]).getMinutes() + ':' + new Date(params.value[3]).getSeconds() + '<br>'
                            + 'md5:' + params.name + '<br>'
                            + '点击可查看当前车辆的完整轨迹'
                    }
                }
            },
            animation:false
        });
    // 使用刚指定的配置项和数据显示图表。
    myChart.on('click',function (params){
        clearTimeout(timerClick);
        timerClick = setTimeout(function () {
            $('li').remove();
            $('#listInfomation').append('<li class="list-group-item">车号:'+params.value[2]+'</li>');
            var k;
        if(!timer) {
            for (k in dictAllDataAllTag) {
                if (params.value[2]==dictAllDataAllTag[k][0].user) {
                    var str =
                        '类型:' + tag2name[dictAllDataAllTag[k][0].tag] + '<br>' +
                        '时间:' + new Date(dictAllDataAllTag[k][0].recitime).getHours() + ':' + new Date(dictAllDataAllTag[k][0].recitime).getMinutes() + ':' + new Date(dictAllDataAllTag[k][0].recitime).getSeconds() + '<br>' +
                        '车号:' + dictAllDataAllTag[k][0].user + '<br>' +
                        '经度:'+params.value[0]+ '<br>'+
                        '纬度:' +params.value[1] ;
                    $('#listInfomation').append('<li class="list-group-item">' + str + '</li>')
                }
            }
        }
        else {
            for (k in dictAllDataAllTag) {
                if (userToShow.indexOf(dictAllDataAllTag[k][0].user)!=-1) {
                    var str =
                        '类型:' + tag2name[dictAllDataAllTag[k][0].tag] + '<br>' +
                        '时间:' + new Date(dictAllDataAllTag[k][0].recitime).getHours() + ':' + new Date(dictAllDataAllTag[k][0].recitime).getMinutes() + ':' + new Date(dictAllDataAllTag[k][0].recitime).getSeconds() + '<br>' +
                        '车号:' + dictAllDataAllTag[k][0].user + '<br>' +
                        '经度:'+params.value[0]+ '<br>'+
                        '纬度:' +params.value[1] ;
                    $('#listInfomation').append('<li class="list-group-item">' + str + '</li>')
                }
            }
        }
        $('#listInfomation').append('<li class="list-group-item" onclick="removeli()">清除信息</li>')
        },300);
    });

    myChart.on('DblClick',function (params) {
        clearTimeout(timerClick);
        var inputId = $("#inputId").val();
        if(inputId==""){
            inputId = params.value[2];
        }else {
            inputId = inputId + ',' + params.value[2];
        }
        $("#inputId").val(inputId);
        inputId = inputId.split(',');
        userToShow = inputId.map(Number);
    });
    myChart.setOption(option);
}

function play() {
    // if(timer) return;
    var myChart = echarts.init(document.getElementById('main'));
    speed = document.getElementById('speedControl').innerHTML.slice(2, 3);
    option.series = [];
    option.series.push(
        {
            name: '出租车',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            // data: convertDataWithTime(data_Tag1, 1, time),
            data: selectDataByUser(convertDataWithTime(data_Tag1, 1, time),userToShow),
            symbolSize: function (val) {
                return SymbleSize * data_Flag1;

                // return 10;
            },
            itemStyle: {
                normal: {
                    // color: 'purple'
                    color:function (params){
                        return ColorFlag==0?'#ce504a':colorMap[params.value[2]]
                    }
                }
            },
            animation:true
        },
        {
            name: '公交车',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            data: selectDataByUser(convertDataWithTime(data_Tag2, 2, time),userToShow),
            symbolSize: function (val) {
                return SymbleSize * data_Flag2;

                // return 10;
            },
            itemStyle: {
                normal: {
                    // color: 'blue'
                    // color: '#f7c550'
                    color:function (params){
                        return ColorFlag==0?'#f7c550':colorMap[params.value[2]]
                    }
                }
            },
            animation:true
        },
        {
            name: '私家车',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            data: selectDataByUser(convertDataWithTime(data_Tag3, 3, time),userToShow),
            symbolSize: function (val) {
                return SymbleSize * data_Flag3;

            },
            itemStyle: {
                normal: {
                    // color: 'green'
                    // color:'#9aeec1'
                    color:function (params){
                        return ColorFlag==0?'#9aeec1':colorMap[params.value[2]]
                    }
                }
            },
            animation:true
        },
        {
            name: '自行车',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            data: selectDataByUser(convertDataWithTime(data_Tag5, 5, time),userToShow),
            symbolSize: function (val) {
                return SymbleSize * data_Flag5 ;

            },
            itemStyle: {
                normal: {
                    // color: 'pink'
                    // color:'#7f7ec3'
                    color:function (params){
                        return ColorFlag==0?'#7f7ec3':colorMap[params.value[2]]
                    }
                }
            },
            animation:true
        },
        {
            name: '地铁',
            type: 'scatter',
            polyline: true,
            coordinateSystem: 'bmap',
            data: selectDataByUser(convertDataWithTime(data_Tag4, 4, time),userToShow),
            symbolSize: function (val) {
                return SymbleSize * data_Flag4 ;

            },
            itemStyle: {
                normal: {
                    // color: 'red'
                    // color: '#52a1d5'
                    color:function (params){
                        return ColorFlag==0?'#52a1d5':colorMap[params.value[2]]
                    }
                }
            },
            animation:true
        });
    // 使用刚指定的配置项和数据显示图表。
    time = time + start_time;
    timer = setInterval(function () {
        option.series[0].data = selectDataByUser(convertDataWithTime(data_Tag1, 1, time),userToShow);
        option.series[1].data = selectDataByUser(convertDataWithTime(data_Tag2, 2, time),userToShow)
        option.series[2].data = selectDataByUser(convertDataWithTime(data_Tag3, 3, time),userToShow)
        option.series[3].data = selectDataByUser(convertDataWithTime(data_Tag4, 4, time),userToShow)
        option.series[4].data = selectDataByUser(convertDataWithTime(data_Tag5, 5, time),userToShow)
        myChart.setOption(option);
        if(time>myDate.getTime()+end_time) {
            time = myDate.getTime() + start_time;
            degree = 0;
            if(timer)
                clearInterval(timer);
            if(timerRose)
                clearInterval(timerRose);
        }
        time = time + timepass;
    }, 1000 / speed)
}
function pause() {
    clearInterval(timer);
    clearInterval(timerRose)
}
function stop() {
    clearInterval(timer);
    clearInterval(timerRose);
    timer = null;
    // timerRose = null;
    stopRoseMap();
    start_time = (($('#startTimeSelect').val().slice(0,2)*3600+$('#startTimeSelect').val().slice(3,5)*60)*1000);
    time = myDate.getTime()+start_time;
    option.series = [];
    data_Flag1 = 1;
    data_Flag2 = 1;
    data_Flag3 = 1;
    data_Flag4 = 1;
    data_Flag5 = 1;
    showAllData();
}
function speedchange() {
    clearInterval(timer);
    clearInterval(timerRose);
    option.series = [];
    if (document.getElementById('speedControl').innerHTML == 'X 1')
        document.getElementById('speedControl').innerHTML = 'X 2';
    else if (document.getElementById('speedControl').innerHTML == 'X 2')
        document.getElementById('speedControl').innerHTML = 'X 4';
    else if (document.getElementById('speedControl').innerHTML == 'X 4')
        document.getElementById('speedControl').innerHTML = 'X 8';
    else if (document.getElementById('speedControl').innerHTML == 'X 8')
        document.getElementById('speedControl').innerHTML = 'X 1';
    play();
    playRoseMap();
}

function zoomRateUp() {
    zoomRate = zoomRate + 1;
    option.bmap.zoom = zoomRate;
    showMap();
}
function zoomRateDown() {
    zoomRate = zoomRate - 1;
    option.bmap.zoom = zoomRate;
    showMap();
}

function symbolSizeFlagChange() {
    if(document.getElementById('showSymbolSize').innerText=='展示轨迹'){
        ColorFlag = 1;
        document.getElementById('showSymbolSize').innerText='不展示轨迹'
    }
    else if (document.getElementById('showSymbolSize').innerText=='不展示轨迹'){
        ColorFlag = 0;
        document.getElementById('showSymbolSize').innerText='展示轨迹'
    }
    var myChart = echarts.init(document.getElementById('main'));
    myChart.setOption(option);
}

function removeli() {
    $('li').remove();
}